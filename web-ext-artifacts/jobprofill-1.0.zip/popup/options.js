$(document).ready(function (e) {
    if (!localStorage.getItem('profileOptions')) {
        let initValues = {
            "invalid": "--Select Profile--",
            "new": "Create New..."
        };
        localStorage.setItem('profileOptions', JSON.stringify(initValues));
    }
    
    var profiles = JSON.parse(localStorage.getItem('profileOptions'));
    $.each(profiles, function (key, value) {
        $('#profiles').append($("<option></option>").attr("value", key).text(value).append("&nbsp;&nbsp;"));
        let recentProfile = localStorage.getItem('recentProfile');
        if (recentProfile) {
            $('#profiles').val(recentProfile).change();
        }
    });
    $('#profiles').on('change', function (e) {
        e.preventDefault();
        if (this.value === "new") {
            $('.name-card').removeClass('d-none');
            $('#profileName').focus();
        } else {
            $('.name-card').addClass('d-none');
        }
    });
    $('#btnOK').on('click', function (e) {
        e.preventDefault();
        let name = $('#profileName').val();
        if (name) {
            $('#profileName').removeClass('error-focused');
            $('.name-card').addClass('d-none');
            let key = name.replace(/\s+/g, '').toLowerCase();
            profiles[key] = name;
            $('#profiles').append($("<option></option>").attr("value", key).text(name).append("&nbsp;&nbsp;"));
            $('#profiles').val(key).change();
            localStorage.setItem('profileOptions', JSON.stringify(profiles));
            localStorage.setItem('recentProfile', key);
        } else {
            $('#profileName').addClass('error-focused');
        }
    });
    $('#btnCancel').on('click', function (e) {
        e.preventDefault();
        $('.name-card').addClass('d-none');
    });
    $('#saveProfile').on('click', function (e) {
        e.preventDefault();
        var profileNameVal = $('#profiles').val();
        console.log(profileNameVal);
        
        if (profileNameVal !== 'invalid' && profileNameVal !== 'new') {
            browser.tabs.executeScript({file: "/content_scripts/autofill.js"})
                .then(listenForClicks)
                .catch(reportExecuteScriptError);
            
        } else {
            $('#profiles').focus();
        }
    });
    
    function listenForClicks(result) {
        $('#saveSuccess').show().delay(2000).fadeOut();
    }
    
    function reportExecuteScriptError(error) {
        console.log(`Error: ${error}`);
    }
    
});
