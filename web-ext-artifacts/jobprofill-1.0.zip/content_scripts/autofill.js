var labels = $('label');
//console.log(labels);

var fNameRegex = /f(irst)?((\w+)*|\s|\w+\s|(\w+)?\W)name/i;
var lNameRegex = /l(ast)?((\w+)*|\s|\w+\s|(\w+)?\W)name/i;
var emailRegex = /email/i;
var phoneRegex = /phone/i;
var cellRegex = /cell/i;
var addressRegex = /address/i;
var streetRegex = /street/i;
var cityRegex = /city/i;
var stateRegex = /state/i;
var zipRegex = /zip/i;
var employerRegex = /employer/i;
var companyNameRegex = /organization/i;
var companyPositionRegex = /job((\w+)*|\s|\w+\s|(\w+)?\W)function/i;
var companyTitleRegex = /(job)?((\w+)*|\s|\w+\s|(\w+)?\W)title/i;
var schoolNameRegex = /school/i;
var institutionRegex = /institution/i;
var fieldOfStudyRegex = /discipline/i;
var degreeRegex = /degree/i;
var areaOfStudyRegex = /area\sof\sstudy/i;
var certificateRegex = /certificat/i;
var linkedInRegex = /LinkedIn/i;
var authorizationRegex = /authorized/i;
var visaStatusRegex = /visa/i;
var visasponsorshipRegex = /sponsorship/i;

var userProfile = {};

$.each(labels, function (key, label) {
    console.log(label.innerText);
    let findInput = $(label).next();
    let val;
    if ((findInput.is('div') && findInput.children().length > 1) || findInput.length > 1) {
        while (findInput.length) {
            findInput = findInput.children();
        }
        val = $(findInput).end().val();
    } else
        val = $(findInput).val();
    if (val) {
        if (fNameRegex.test(label.innerText) && val) {
            userProfile['firstName'] = val;
        } else if (lNameRegex.test(label.innerText) && val) {
            userProfile['lastName'] = val;
        } else if (emailRegex.test(label.innerText) && val) {
            userProfile['email'] = val;
        } else if (phoneRegex.test(label.innerText) && val) {
            userProfile['phone'] = val;
        } else if (cellRegex.test(label.innerText) && val) {
            userProfile['cell'] = val;
        } else if (addressRegex.test(label.innerText) && val) {
            userProfile['address'] = val;
        } else if (streetRegex.test(label.innerText) && val) {
            userProfile['street'] = val;
        } else if (cityRegex.test(label.innerText) && val) {
            userProfile['city'] = val;
        } else if (stateRegex.test(label.innerText) && val) {
            userProfile['state'] = val;
        } else if (zipRegex.test(label.innerText) && val) {
            userProfile['zip'] = val;
        } else if (employerRegex.test(label.innerText) && val) {
            userProfile['employer'] = val;
        } else if (companyNameRegex.test(label.innerText) && val) {
            userProfile['organization'] = val;
        } else if (companyPositionRegex.test(label.innerText) && val) {
            userProfile['companyPosition'] = val;
        } else if (companyTitleRegex.test(label.innerText) && val) {
            userProfile['companyTitle'] = val;
        } else if (schoolNameRegex.test(label.innerText) && val) {
            userProfile['school'] = val;
        } else if (institutionRegex.test(label.innerText) && val) {
            userProfile['institution'] = val;
        } else if (fieldOfStudyRegex.test(label.innerText) && val) {
            userProfile['fieldOfStudy'] = val;
        } else if (degreeRegex.test(label.innerText) && val) {
            userProfile['degree'] = val;
        } else if (areaOfStudyRegex.test(label.innerText) && val) {
            userProfile['areaOfStudy'] = val;
        } else if (certificateRegex.test(label.innerText) && val) {
            userProfile['certificate'] = val;
        } else if (linkedInRegex.test(label.innerText) && val) {
            userProfile['linkedIn'] = val;
        } else if (authorizationRegex.test(label.innerText) && val) {
            userProfile['authorization'] = val;
        } else if (visaStatusRegex.test(label.innerText) && val) {
            userProfile['visa'] = val;
        } else if (visasponsorshipRegex.test(label.innerText) && val) {
            userProfile['sponsorship'] = val;
        }
    }
    console.log(userProfile);
});

undefined;